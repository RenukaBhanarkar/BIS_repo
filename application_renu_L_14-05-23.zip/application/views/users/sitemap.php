<div id="privacy-content" class="container">
    <div class="row">
        <div class="static-content">
            <div class="bloginfo">
                <h3 style="margin-bottom: 0px;margin-top:20px;color: #0086b2!important;font-weight: 600;">Sitemap</h3>
            </div>
            <div class="heading-underline" style="width: 200px;">
                <div class="left"></div><div class="right"></div>
             </div>
         </div>
    </div>
    <div class="row">
        <div class="col-md-6">
            <div class="sitenav">
                <ul>
                    <li><a href="#">Home</li>
                    <li><a href="#">BIS</li>
                    <li><a href="#">About Exchange Forum</li>
                    <li><a href="#">Know Your Standards</li>
                    <li><a href="#">Contact Us</li>
                    <li><a href="#">NBC</li>
                    <li><a href="#">NEC</li>
                    <li><a href="#">SNAP 2022-27</li>    
                </ul>    
            </div>
        </div>
        <div class="col-md-6">
            <div class="sitenav">
            </div>
        </div>  
    </div>          
  </div>
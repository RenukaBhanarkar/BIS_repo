<section id="exchange_forum">
     <div class="container-fluid">
        <div class="row">
            <div class="exchange_section d-flex">
                <div class="col-md-2">
                    <div class="bis_logo">
                       <img src="<?php echo base_url(); ?>assets/images/bis_logo.png" class="opacity_img"> 
                    </div>
                    
                 </div>
         <div class="col-md-8" id="Forum">
                 <div class="bis_welcome">
                     <a href="">
                         <h2>Welcome to Online Exchange Forum</h2>
                     </a>
                 </div>
                <div class="platform">
                         <h4>(A platform for exchange of information & online activities on Standards)</h4>
                 </div>
             </div>
        <div class="col-md-2">
                 <div class="bis_logo">
                       <img src="<?php echo base_url(); ?>assets/images/bis_logo.png" class="opacity_img"> 
                  </div>
                 </div>
              </div>
            </div>
        </div>
    </section>
    <section id="bottom_content">
        <div class="container">
            <div class="row">
               <div class="live_data">
                        <!-- <h6>Live Data</h6> -->
                        <div class="row table_data ">
                            
                            <div class="innerBox">
                                <a href="<?=base_url();?>users/standard">
                                <div class="LiveDataBox">
                                     <img src="<?=base_url();?>assets/images/compliant.png" class="livedata_icons">
                                      <h3 class="text_standard">Standard Club</h3>
                                     <p class="mb-0">(An initiative to nurture the standards as Brand Ambassadors of Quality & Standards)</p>
                                </div>
                                </a>
                            </div>
                            <div class="innerBox">
                                <a href="<?=base_url();?>users/quality_index">
                                  <div class="LiveDataBox">
                                      <img src="<?=base_url();?>assets/images/warranty.png" class="livedata_icons">
                                       <h3 class="text_standard">World of Standards</h3>
                                       <p class="mb-0">(An initiative to broad base the stakeholder engagement and development of standards)</p>
                                 </div>
                                 </a>
                            </div>
                          </div>
                     </div>
                </div>
           </div>
    </section>
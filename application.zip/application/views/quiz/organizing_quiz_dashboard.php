    <!-- Begin Page Content -->
    <div class="container-fluid">

        <!-- Page Heading -->
        <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0 text-gray-800">Competition</h1>
           <nav style="--bs-breadcrumb-divider: url(&#34;data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='8' height='8'%3E%3Cpath d='M2.5 0L1 1.5 3.5 4 1 6.5 2.5 8l4-4-4-4z' fill='%236c757d'/%3E%3C/svg%3E&#34;);" aria-label="breadcrumb">
                <ol class="breadcrumb">
                <?php if (encryptids("D", $_SESSION['admin_type']) == 3) { ?>
                <li class="breadcrumb-item"><a href="<?php echo base_url().'Admin/dashboard';?>" >Sub Admin Dashboard</a></li>
                <?php }else{ ?>
                    <li class="breadcrumb-item"><a href="<?php echo base_url().'Admin/dashboard';?>" >Admin Dashboard</a></li>
                    <?php } ?>
                <li class="breadcrumb-item"><a href="<?php echo base_url().'admin/exchange_forum';?>" >Exchange Forum</a></li>
                <li class="breadcrumb-item active" aria-current="page">Competitions</li>
                
                </ol>
            </nav>
        </div>
       
       
        <!-- Content Row -->
        <div class="row">
            <!-- Earnings (Monthly) Card Example -->
            <?php if (encryptids("D", $_SESSION['admin_type']) == 3) { ?>
            <?php if(in_array(1, $_SESSION['main_mod_per'])){ ?> 
            <div class="col-xl-3 col-md-6 mb-4">
                <a href="<?php echo base_url(); ?>quiz/quiz_dashboard">
                <div class="card border-left-primary shadow h-100 py-2">
                    <div class="card-body">
                        <div class="row no-gutters align-items-center d-flex">
                            <h5 class="font-weight-bold text-success mb-1">Quiz Competition</h5>                          

                        </div>
                    </div>
                </div>
                </a>
            </div>
            <?php } ?>
            <!-- Earnings (Monthly) Card Example -->
            <?php if(in_array(2, $_SESSION['main_mod_per'])){ ?> 
            <div class="col-xl-3 col-md-6 mb-4">
                <a href="<?php echo base_url(); ?>Standardswritting/standard_offline_dashboard">
                <div class="card border-left-primary shadow h-100 py-2">
                    <div class="card-body">
                        <div class="row no-gutters align-items-center d-flex">
                            <h5 class="font-weight-bold text-primary mb-1">Standard Writting</h5>
                           

                        </div>
                    </div>
                </div>
                </a>
            </div>
            <?php } ?>
            <?php if(in_array(3, $_SESSION['main_mod_per'])){ ?> 
            <div class="col-xl-3 col-md-6 mb-4">
                <a href="<?php echo base_url(); ?>Standardswritting/miscellaneous_dashboard">
                <div class="card border-left-primary shadow h-100 py-2">
                    <div class="card-body">
                        <div class="row no-gutters align-items-center d-flex">
                            <h5 class="font-weight-bold text-danger mb-1">Miscellaneous Competition</h5>
                            

                        </div>
                    </div>
                </div>
                </a>
            </div>
            <?php } ?>
            <?php } else { ?>
               
            <div class="col-xl-3 col-md-6 mb-4">
                <a href="<?php echo base_url(); ?>quiz/quiz_dashboard">
                <div class="card border-left-primary shadow h-100 py-2">
                    <div class="card-body">
                        <div class="row no-gutters align-items-center d-flex">
                            <h5 class="font-weight-bold text-success mb-1">Quiz Competition</h5>                          

                        </div>
                    </div>
                </div>
                </a>
            </div>
           
            <div class="col-xl-3 col-md-6 mb-4">
                <a href="<?php echo base_url(); ?>Standardswritting/standard_writting_dashboard">
                <div class="card border-left-primary shadow h-100 py-2">
                    <div class="card-body">
                        <div class="row no-gutters align-items-center d-flex">
                            <h5 class="font-weight-bold text-primary mb-1">Standard Writting</h5>
                           

                        </div>
                    </div>
                </div>
                </a>
            </div>
            
            <div class="col-xl-3 col-md-6 mb-4">
                <a href="<?php echo base_url(); ?>Standardswritting/miscellaneous_dashboard">
                <div class="card border-left-primary shadow h-100 py-2">
                    <div class="card-body">
                        <div class="row no-gutters align-items-center d-flex">
                            <h5 class="font-weight-bold text-danger mb-1">Miscellaneous Competition</h5>
                            

                        </div>
                    </div>
                </div>
                </a>
            </div>
           
            <?php } ?>

          </div>
       </div>
    <!-- /.container-fluid -->

</div>
<!-- End of Main Content -->

<!-- Footer -->



<section>
     <div class="container-fluid">
        <div class="row">
            <div class="exchange_section d-flex">
                <div class="col-md-2">
                    <div class="bis_logo">
                       <img src="<?php echo base_url(); ?>assets/images/bis_logo.png" class="opacity_img"> 
                    </div>
                    
                 </div>
         <div class="col-md-8" id="Forum">
                 <div class="bis_welcome">
                     <a href="">
                         <h2>Welcome to Online Exchange Forum</h2>
                     </a>
                 </div>
                <div class="platform">
                         <h4>(A platform for exchange of information and conducting Standards based activities)</h4>
                 </div>
             </div>
        <div class="col-md-2">
                 <div class="bis_logo">
                       <img src="<?php echo base_url(); ?>assets/images/bis_logo.png" class="opacity_img"> 
                  </div>
                 </div>
              </div>
            </div>
        </div>
    </section>
    <section id="bottom_content">
        <div class="container">
            <div class="row">
               <div class="live_data">
                        <!-- <h6>Live Data</h6> -->
                        <div class="row table_data ">
                            
                            <div class="innerBox" style="background-image: url(<?php echo base_url();?>assets/images/standard_club.jpeg); padding: 0px; margin: 0px; background-repeat: round;">
                            <div style="background:#00000099;">
                                <a href="<?=base_url();?>users/standard">
                                <div class="LiveDataBox" style="height: 182px; overflow: hidden;" >
                                     <!-- <img src="<?=base_url();?>assets/images/compliant.png" class="livedata_icons"> -->
                                      <h3 class="text_standard">Standards Club</h3>
                                     <p class="mb-0">(An initiative to nurture the students as Brand Ambassadors of Quality)</p>
                                </div>
                                </a>
                                </div>
                            </div>
                            <div class="innerBox" style="background-image: url(<?php echo base_url();?>assets/images/world_standard.jpeg); padding: 0px; margin: 0px; background-repeat: round;">
                            <div style="background:#00000099;">
                                <a href="<?=base_url();?>users/quality_index">
                                  <div class="LiveDataBox" style="height: 182px; overflow: hidden;">
                                      <!-- <img src="<?=base_url();?>assets/images/warranty.png" class="livedata_icons"> -->
                                       <h3 class="text_standard">World of Standards</h3>
                                       <p class="mb-0">(An initiative to broad-base the stakeholder engagement for development of Standards)</p>
                                 </div>
                                 </a>
                            </div>
                            </div>
                          </div>
                     </div>
                </div>
           </div>
    </section>
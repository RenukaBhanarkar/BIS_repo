<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Standardswritting_model extends CI_Model {

      public function StandardswrittingSave($formdata)
    {
        $this->db->insert('tbl_standards_writting_offline',$formdata); 
        return $insert_id = $this->db->insert_id();
    }
    public function create_standard_list()
    {   
         $this->db->where('status ',0);  
        return $this->db->get('tbl_standards_writting_offline')->result_array();
    }
    public function view_standards($id)
    { 
        $this->db->where('id ',$id);  
        return $this->db->get("tbl_standards_writting_offline")->row_array();
    }

    public function updateStatus($formdata,$id)
    {
        $this->db->where('id', $id);
        return $this->db->update('tbl_standards_writting_offline', $formdata);
    }

    public function deleteData($id)
    {
        $this->db->where('id', $id);
        return $this->db->delete('tbl_standards_writting_offline');
    }
     
}
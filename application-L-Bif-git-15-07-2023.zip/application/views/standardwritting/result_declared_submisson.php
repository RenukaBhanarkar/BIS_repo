<!-- Begin Page Content -->
<div class="container-fluid">
    <!-- Page Heading -->
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
    <h1 class="h3 mb-0 text-gray-800">Result Declared List</h1>
            <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo base_url().'Admin/dashboard';?>" >Sub Admin Dashboard</a></li>
                <li class="breadcrumb-item"><a href="<?php echo base_url().'admin/exchange_forum';?>" >Exchange Forum</a></li>
                <li class="breadcrumb-item"><a href="<?php echo base_url().'quiz/organizing_quiz';?>" >Competition</a></li>
                <li class="breadcrumb-item"><a href="<?php echo base_url().'Standardswritting/standard_offline_dashboard';?>" >Standard Writting Dashboard</a></li>
                <li class="breadcrumb-item"><a href="<?php echo base_url().'Standardswritting/standard_online_dashboard';?>" >Standard Writting</a></li>
                <li class="breadcrumb-item active" aria-current="page">Result Declared List</li>
                
                </ol>
            </nav>
        
    </div>
    
    
    <!-- Content Row -->
    
    <div class="row">
        <div class="col-12 mt-3">
            <div class="card border-top card-body ">
            <?php if(!empty ($DeclarationList)) { ?> 
                <table id="example" class="table-bordered display nowrap table-responsive" style="width:100%">
                    <thead>
                        <tr>                            
                            <th>Sr. No.</th>
                            <th>Name of Competition</th>
                            <th>Competition ID</th>
                            <th>Competition Date</th>
                            <th>Total Marks</th>
                            <th>Total Submission</th>
                            <th>Total Winners</th>
                            <th>Declared on</th>
                            <th>Action</th>                        
                            
                        </tr>
                    </thead>
                   
                    <tbody>   
                    <?php foreach ($DeclarationList as $key => $value): ?>
                        <tr>
                            <td><?= $key+1?></td>
                            <td><?= $value['title']?></td>
                            <td><?= $value['comp_id']?></td>
                            <td><?= $value['start_date']?></td>
                            <td><?= $value['total_mark']?></td>
                            <td><?= $value['total_submissions']?></td>
                            <td><?= $value['total_winners']?></td>
                            <td><?= $value['declared_on']?></td>
                            <td>
                            <?php if (encryptids("D", $_SESSION['admin_type']) == 2) { ?>
                                <?php $id= encryptids("E", $value['comp_id'] )?>
                                <a href="<?php echo base_url();?>standardswritting/result_declared_view/<?= $id;?>" class="btn btn-primary btn-sm mr-2">View</a>
                            
                               
                            <?php } ?>
                            <?php if (encryptids("D", $_SESSION['admin_type']) == 3) { ?>
                                <?php //if (in_array(1, $permissions)) { ?>
                                <?php $id= encryptids("E", $value['comp_id'] )?>
                                <a href="<?php echo base_url();?>standardswritting/result_declared_view/<?= $id;?>" class="btn btn-primary btn-sm mr-2">View</a>
                            <?php //} ?>
                        
                             <?php } ?>

                            </td>
                            
                        </tr>
                        
                        <?php endforeach ?>   
                        
                    </tbody>
                </table>
                <?php } else { ?>
                <div class="alert alert-warning">Details are not available</div>
                <?php } ?> 
               
            </div>
        </div>
    </div>
</div>
<!-- /.container-fluid -->
</div>
<!-- End of Main Content -->
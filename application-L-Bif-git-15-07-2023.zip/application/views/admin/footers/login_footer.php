<script>
var message = "This function is not allowed here";

function rtclickcheck(keyp) {
    if (navigator.appName == "Netscape" && keyp.which == 3) {
       alert(message);
        return false;
    }
    if (navigator.appVersion.indexOf("MSIE") != -1 && event.button == 2) {
       alert(message);
        return false;
    }
}
</script>
</body>

</html>
<link href="<?php echo base_url(); ?>assets/css/quiz_start.css" rel="stylesheet" />
<link href="<?php echo base_url(); ?>assets/css/standard_submission.css" rel="stylesheet" />
<section style="min-height: calc(100vh - 300px);">
        <div class="row">
            <div class="offset-md-2 col-md-8">
                <div class="quiz-left-side-main shadow">
                    <div class="thank_you_box" id="thankYou">
                        <!-- <img src="assets/images/certificate.png" alt=""> -->
                        <div class="text_box">
                            <h4>Thank You </h4>
                            <p>For Your Participation.</p>
                            <!-- <p class="Certificate-link"><a href="#">Click here</a> to download the Certificate</p> -->
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<!-- <div class=content>
  <div class="wrapper-1">
    <div class="wrapper-2">
      <h1>Thank you for your Participation.</h1>
      <p>for contacting us, we will get in touch with you soon...</p>
      
      <button class="go-home" onclick="location.href = '<?php echo base_url(); ?>Users/welcome';">
      Back to Home
      </button>
    </div>
    <div class="footer-like">
      <p>Email not received?
       <a href="#">Click here to send again</a>
      </p>
    </div>
</div>
</div> -->
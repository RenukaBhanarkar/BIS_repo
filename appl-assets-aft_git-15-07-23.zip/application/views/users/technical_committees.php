<style>
    .heading-underline .right{
        width:10%;
    }
</style>
<div id="privacy-content" class="container">
    <div class="col-sx-12 col-sm-12 col-md-12" style="border-left: 3px solid cadetblue; padding: 0px 25px;">
        <div class="static-content">
            <div class="bloginfo">
                <h3 style="margin-bottom: 0px;margin-top:20px;color: #0086b2!important;font-weight: 600;">Offers for the Membership of Technical Committees</h3>
            </div>
            <div class="heading-underline" style="width: 200px;">
                <div class="left"></div><div class="right"></div>
             </div>
             <div class="bloginfo">
                            <!-- <h4 style="margin-bottom: 0px;">Audio &amp; Videos</h4><br>
                            <p>You shall also find links to videos of speeches, interviews given by Chairman of PMRDA at national and international events such as conferences. The videos are drawn from Aadhaar Channel in YouTube.</p> -->
            <div class="col-md-12 mt-3">
            
                <table class="table hover table-bordered">
                <thead>
                            		<tr>
                                        <th>Sr.No.</th>
                            			<th>Technical Department</th>
                            			<th>No. of Vacancies</th>
                            			
                            		</tr>
                            	</thead>
                            	<tbody>
                            		<tr>
                            			<td>1</td>
                            			<td>Department</td>
                            			<td><a href="#">2</a></td>
                            		</tr>
                            		<tr>
                            			<td>2</td>
                            			<td>Department</td>
                            			<td><a href="#">3ss</a></td>
                            		</tr>
                            		
                            	</tbody>
                            </table>
                        </div>    
                    </div>
                   
                </div>
         </div>
    </div>
  </div>
  <script>
    $(document).ready(function () {
    $('#example_1').DataTable();
    });
   </script>
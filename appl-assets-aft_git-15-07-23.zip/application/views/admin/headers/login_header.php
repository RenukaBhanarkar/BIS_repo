<!doctype html>
 <html lang="en">

 <head>
     <meta charset="utf-8">
     <meta name="viewport" content="width=device-width, initial-scale=1">
     <meta name="keywords" content="Bureau of Indian standard">
     <meta name="description" content="Bureau of Indian standard">

     <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" crossorigin="anonymous" />

     <title>Bureau of Indian standard</title>
     <link href="<?php echo base_url(); ?>assets/css/bootstrap.min.css" rel="stylesheet">
     <link rel="preconnect" href="https://fonts.googleapis.com">
     <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
     <link href="https://fonts.googleapis.com/css2?family=Roboto&display=swap" rel="stylesheet">
     <link href="" rel="stylesheet">

     <link href="<?php echo base_url(); ?>assets/css/blueThemestyle.css" rel="stylesheet" />
     <link rel="shortcut icon" href="assets/images/bis_logo.png" type="image/x-icon">
     <style>

     </style>
 </head>

 <body>